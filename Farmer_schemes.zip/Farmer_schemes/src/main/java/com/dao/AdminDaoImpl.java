package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.model.Admin;
import com.model.Bidder;
import com.model.Bidding;
import com.model.Farmer;
import com.model.SellRequest;
@Repository("adminDao")
public class AdminDaoImpl implements AdminDao {
	@PersistenceContext
	EntityManager em;
	public List<Farmer> getFarmers(){
	
		@SuppressWarnings("unchecked")
		List<Farmer> list=em.createQuery("Select f from Farmer f").getResultList();
		return list;
		
	}
	
	public List<Bidder> getBidder(){
		
		@SuppressWarnings("unchecked")
		List<Bidder> alist=em.createQuery("Select b from Bidder b").getResultList();
		return alist;
	}
	
	public List<Bidding> getBidding()
	{
		@SuppressWarnings("unchecked")
		List<Bidding> hlist=em.createQuery("Select b from Bidding b").getResultList();
		return hlist;
	}
	public boolean validateAdmin(Admin admin)
	{

		boolean result=false;
		try{
	
	    Admin u=em.find(Admin.class,admin.getUserid());
		System.out.println(result+"1");
	   // System.out.println(admin.getUserid());
		
		if(u!=null)
		{
			if(u.getPassword().equals(admin.getPassword()))
				{
				result=true;
			    //System.out.println(result+"2");
				}
		}
		//System.out.println(result+"3");
		em.close();
	}
		catch(Exception e)
		{
			System.out.println("error:"+e);
		}
		//System.out.println(result+"4");
		return result;
		
	}
	
	
	public List<Object[]> getBiddingList()
	{
	
		Query q=em.createNativeQuery("select * from sell where sysdate between start_date and end_date");
		/*List<Object[]> res = query.getResultList();*/
		@SuppressWarnings("unchecked")
		List<Object[]> list=q.getResultList();
	
		return list;
	}
	
public List<Object[]> searchSellRequest(SellRequest request1)
	
	{
		int c_id = request1.getC_id();
		@SuppressWarnings("unchecked")
		List<Object[]> list =em.createNativeQuery("select s.c_id,s.crop_type,s.crop_name,bidding_amount ,s.f_email,b.b_email from sell s join bidding b on s.c_id=b.c_id  where s.c_id=:c_id order by b.bidding_amount desc").setParameter("c_id", c_id).getResultList();
	    System.out.println(list);
		return list;
	}
	
}

