package com.dao;

import com.model.SellRequest;

public interface sellDao {

	

	public boolean insertSellRequest(SellRequest request);
}
