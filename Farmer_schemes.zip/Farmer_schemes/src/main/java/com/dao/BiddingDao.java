package com.dao;

import java.util.List;

import com.model.Bidding;
import com.model.SellRequest;

public interface BiddingDao {
	public List<Object[]> getBiddingList();
	public List<Object[]>  searchSellRequest(SellRequest request1);
    public boolean insertBiddingDetails(Bidding bidding);
   
	/*public List<Object[]> persistAmountData(SellRequest request1);*/

}
