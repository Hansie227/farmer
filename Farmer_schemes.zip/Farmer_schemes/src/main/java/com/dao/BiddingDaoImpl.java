package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.model.Bidding;
import com.model.SellRequest;



@Repository("biddingDao")
public class BiddingDaoImpl implements BiddingDao {
	@PersistenceContext
	EntityManager em;
	@SuppressWarnings("unchecked")
	
	public boolean insertBiddingDetails(Bidding bidding)
	{
		boolean flag=false;
	    try {
	    	em.persist(bidding);
	    	System.out.println("end");
	    	flag=true;
	    
	    }
	    catch(Exception e) { 
	    	System.out.println("Error:"+e);  
	    	}
	    System.out.println("flag3"+flag);
	    return flag;
	}
	public List<Object[]> getBiddingList()
	{
	
		Query q=em.createNativeQuery("select * from sell where sysdate between start_date and end_date");
		/*List<Object[]> res = query.getResultList();*/
		@SuppressWarnings("unchecked")
		List<Object[]> list=q.getResultList();
	
		return list;
	}
	//public Object searchSellRequest(SellRequest request1)
	public List<Object[]> searchSellRequest(SellRequest request1)
	
	{
		int c_id = request1.getC_id();
		List<Object[]> list =em.createNativeQuery("select s.c_id,s.crop_type,s.crop_name,bidding_amount from sell s join bidding b on s.c_id=b.c_id  where s.c_id=:c_id order by b.bidding_amount desc").setParameter("c_id", c_id).getResultList();
	    System.out.println(list);
		return list;
	}
		
	/*public List<Object[]> persistAmountData(SellRequest request1)
	{
		int c_id = request1.getC_id();
		List<Object[]> list =em.createNativeQuery("select s.c_id,s.crop_type,s.crop_name,bidding_amount from sell s join bidding b on s.c_id=b.c_id  where s.c_id=:c_id").setParameter("c_id", c_id).getResultList();
	    System.out.println(list);
		return list;
	}
	*/
		
}
