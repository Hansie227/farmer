package com.dao;

import java.util.List;

import com.model.Admin;
import com.model.Bidder;
import com.model.Bidding;
import com.model.Farmer;
import com.model.SellRequest;

public interface AdminDao {
	
	public List<Farmer> getFarmers();
	public List<Bidder> getBidder();
	public boolean validateAdmin(Admin admin);
	public List<Bidding> getBidding();
	public List<Object[]> searchSellRequest(SellRequest request1);
	public List<Object[]> getBiddingList();
}
