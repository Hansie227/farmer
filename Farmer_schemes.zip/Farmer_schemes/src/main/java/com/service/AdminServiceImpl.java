package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.AdminDao;
import com.model.Admin;
import com.model.Bidder;
import com.model.Bidding;
import com.model.Farmer;
import com.model.SellRequest;
@Service("adminService")
public class AdminServiceImpl implements AdminService {
	@Autowired
public AdminDao adminDao;
	@Transactional
	public List<Farmer> getFarmers()
	{
	    List<Farmer> list=adminDao.getFarmers();
		return list;
		
	}
	
	@Transactional
	public List<Bidder> getBidder()
	{
	    List<Bidder> alist=adminDao.getBidder();
		return alist;
		
	}

	
	@Transactional
	public List<Bidding> getBidding()
	{
		List<Bidding> hlist=adminDao.getBidding();
		return hlist;
	}
	@Transactional
	public boolean validateAdmin(Admin admin) {
		boolean flag=adminDao.validateAdmin(admin);
		return flag;
	}
	
	@Transactional
	public List<Object[]> getBiddingList()
	{
		List<Object[]> blist=adminDao.getBiddingList();
		return blist;
	}
	

	@Transactional
	public List<Object[]>  searchSellRequest(SellRequest request1)
	{
		List<Object[]>  list=adminDao.searchSellRequest(request1);
		return list;
	}

}
