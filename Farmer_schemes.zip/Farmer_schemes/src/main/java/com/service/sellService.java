package com.service;


import com.model.SellRequest;

public interface sellService {

	
	public boolean insertSellRequest(SellRequest request);
}
