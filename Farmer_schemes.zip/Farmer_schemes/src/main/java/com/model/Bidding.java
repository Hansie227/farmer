package com.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity

public class Bidding {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int bid;
	@Column(length=20)
	private long bidding_amount;
	@Temporal(TemporalType.DATE)
	private Date sys_date;
	@JoinColumn(name="b_email")
	//@ManyToMany(fetch=FetchType.EAGER)
	@ManyToOne(fetch=FetchType.EAGER)
	private Bidder bidder;
	@JoinColumn(name="c_id")
	//@ManyToMany(fetch=FetchType.LAZY)
	@ManyToOne(fetch=FetchType.EAGER)
	private SellRequest requestsell;
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public long getBidding_amount() {
		return bidding_amount;
	}
	public void setBidding_amount(int bidding_amount) {
		this.bidding_amount = bidding_amount;
	}
	public Date getSys_date() {
		return sys_date;
	}
	public void setSys_date(Date sys_date) {
		this.sys_date = sys_date;
	}
	public Bidder getBidder() {
		return bidder;
	}
	public void setBidder(Bidder bidder) {
		this.bidder = bidder;
	}
	public SellRequest getRequestsell() {
		return requestsell;
	}
	public void setRequestsell(SellRequest requestsell) {
		this.requestsell = requestsell;
	}
	public Bidding() {
		super();
	}
	@Override
	public String toString() {
		return "Bidding [bid=" + bid + ", bidding_amount=" + bidding_amount + ", sys_date=" + sys_date + ", bidder="
				+ bidder + ", requestsell=" + requestsell + "]";
	}
	
	
}
