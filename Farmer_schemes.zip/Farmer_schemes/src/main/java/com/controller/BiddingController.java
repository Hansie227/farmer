package com.controller;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Bidder;
import com.model.Bidding;
import com.model.SellRequest;
import com.service.BiddingService;

@Controller("biddingController3")
public class BiddingController {

	@Autowired
	public BiddingService biddingService;
	
	@RequestMapping(value="/biddingrequest", method=RequestMethod.GET)
	public ModelAndView viewbiddinglist()
	{
		 List<Object[]> list=biddingService.getBiddingList();
		ModelAndView mav=new ModelAndView("viewbidding");
		mav.addObject("list",list);
		return mav;
	} 
	
	@RequestMapping(value="/searchrequest", method=RequestMethod.POST)
	public ModelAndView searchBiddingRequest(HttpServletRequest request, HttpServletResponse response)
	{
		ModelAndView mav = null;
		int c_id=Integer.parseInt(request.getParameter("c_id"));
		System.out.println("id"+c_id);
		SellRequest request1=new SellRequest();
		request1.setC_id(c_id);
		/*Bidding bidding=new Bidding();
	    bidding.setRequestsell(request1);*/
		List<Object[]>  request2=biddingService.searchSellRequest(request1);
		
		if(request2!=null)
		{
			System.out.println("request 2 not null");
			mav=new ModelAndView("searchedrequest");
			mav.addObject("request2",request2);
			mav.addObject("c_id",c_id);
		}
		else
		{
			mav=new ModelAndView("unsearched");
			mav.addObject("status","Unsuccessfull");
		}
		return mav;
	}  
	
	/*@RequestMapping(value = "/successbiddingrequest", method = RequestMethod.GET)
	public ModelAndView showReg(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("searchedrequest");
		return mav;
	}
	*/
	@RequestMapping(value = "/successbiddingrequest", method = RequestMethod.POST)
	public ModelAndView addfarmer2(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws ParseException
	
	{
			 int bidding_amount=Integer.parseInt(request.getParameter("bidding_amount"));
			 System.out.println(bidding_amount);	  
			 Bidder bidder=new Bidder();
			 String b_email =(String)session.getAttribute("email"); 
			 System.out.println("ff="+b_email);
			 bidder.setB_email(b_email);
			 System.out.println("email"+bidder.getB_email());
		  
		  int c_id=Integer.parseInt(request.getParameter("c_id"));
		  System.out.println("c_id="+c_id);
		  
		  SellRequest requestsell=new SellRequest();
		  requestsell.setC_id(c_id);
		  
		  System.out.println("cid dikha de"+requestsell.getC_id());
		  Bidding bidding=new Bidding();
		  bidding.setBidding_amount(bidding_amount);
		  bidding.setSys_date(new Date());
		 
		  bidding.setBidder(bidder);
		  bidding.setRequestsell(requestsell);
		  
		  			  
		boolean flag=biddingService.insertBiddingDetails(bidding);
        System.out.println("flag1"+flag);
	  if(flag) 
	  {
	  ModelAndView mav = new ModelAndView("successfullbidding");
	  mav.addObject("bidding", new Bidding());
	  mav.addObject("status","Your Request is Placed Successfully!!!!!");
	  
	  return mav;
	  }
	  else {
	  	ModelAndView mav = new ModelAndView("successfullbidding");
	      mav.addObject("bidding", new Bidding());
	      mav.addObject("status","Sorry! Request for bidding in incomplete");
	      return mav;	
	  }
	  
	/*  List<Object[]> alist=biddingService.persistAmountData(requestsell);

		if(alist!=null)
		{
			System.out.println("request 2 not null");
			ModelAndView mav=new ModelAndView("searchedrequest");
			mav.addObject("alist",alist);
			return mav;
		}
		else
		{
			ModelAndView mav=new ModelAndView("unsearched");
			mav.addObject("status","unsuccessfull");
			return mav;
		}*/
		
	/*
		int c_id1=Integer.parseInt(request.getParameter("c_id"));
		System.out.println("id"+c_id1);
		SellRequest request1=new SellRequest();
		request1.setC_id(c_id1);
    List<Object[]>  request2=biddingService.searchSellRequest(request1);
		
		if(request2!=null)
		{
			System.out.println("request 2 not null");
			 ModelAndView mav=new ModelAndView("searchedrequest");
			mav.addObject("request2",request2);
			return mav;
		}
		else
		{
			 ModelAndView mav=new ModelAndView("unsearched");
			mav.addObject("status","unsuccessfull");
			return mav;
		}
		*/
		
	  
	}
}
